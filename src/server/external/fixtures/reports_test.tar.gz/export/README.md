Fixture for src/server/external/sources.test.ts.
